j = 0

for i in range(5) :
    j = j + 2
    
    if j == 6 :
        continue
    
    print ('i = ', i, ', j = ', j)
