# coding : utf-8

brand = "Apple"
exchangeRate = 1.235235245

message = "이 %s 노트북의 가격은 %d USD이고 환율은 1유로당 %4.2f USD입니다." %(brand,1299,exchangeRate)
print (message)


message = "이 {0:s} 노트북의 가격은 {1:d} USD이고 환율은 1유로당 {2:4.2f} USD입니다.".format(brand,1299,exchangeRate)
print (message)
