message1 = "{0}은 {1}보다 쉽다.".format("파이썬","자바")
message2 = "{1}은 {0}보다 쉽다.".format("파이썬","자바")
message3 = "{:10.2f}와 {:d}".format(1.234234234,12)
message4 = "{}".format(1.234234234)

print(message1)
print(message2)
print(message3)
print(message4)
