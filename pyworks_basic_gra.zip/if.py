userInput = input('input 1 or 2 : ')

if userInput == "1":
    print("Hello World")
    print("WTH")
elif userInput == "2":
    print("Python is awesome!")
    print("WTH")
else :
    print("Wrong number!!")

