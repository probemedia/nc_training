pets = ['cat','dog','rabbit','hamster']

for myPets in pets:
    print(myPets)


for i in range(1,10):
    print(i, end=' ') #2.7 : print i,
