myName = input("name : ")
myAge = input("age : ")

print("name : ", myName, ", age : ", myAge)

print('''Hello
My name is KEO
and My age is 22.''')

print('welcome\nhell')
print('\\')
