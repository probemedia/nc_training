message1 = "global variable"

def myFunc2():
    print("\nin function")
    message1 = "local variable"
    print(message1)
    

myFunc2()
print("\nout function")
print(message1)

