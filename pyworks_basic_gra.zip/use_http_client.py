import http.client

conn = http.client.HTTPConnection('google.com')
conn.request('GET', '/')
resp = conn.getresponse()
body = resp.read()
conn.close() 

if resp.version == 10: 
    print('HTTP/1.0 %s %s' % (resp.status, resp.reason))
if resp.version == 11: 
    print('HTTP/1.1 %s %s' % (resp.status, resp.reason))
for header in resp.getheaders():
    print('%s: %s' % (header[0], header[1]))
print ('\n', body)
