myInt = int(input("input number : "))

num1 = 12 if myInt == 10 else 13

print (num1)
