def checkIfPrime2(numberToCheck):
    for x in range(2,numberToCheck):
        if(numberToCheck%x == 0) :
            return "non prime number"
        
    return "prime number"

