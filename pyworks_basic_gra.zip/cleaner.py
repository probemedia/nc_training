'''
Created on 2015. 12. 16.

@author: KEO
'''
#coding:utf-8
import turtle
import math
import random

class Line:
    def __init__(self,slp,x0,y0):
        self.slp = float(slp)
        self.x0 = float(x0)
        self.y0 = float(y0)

    def get_y(self,x):
        return self.slp * (x-self.x0) + self.y0

    def get_x(self,y):
        return self.x0 + (y - self.y0) / self.slp

class Geobuk(turtle.Turtle):
    def __init__(self):
        super(Geobuk,self).__init__()
        self.shape('turtle')
        self.shapesize(2,2)
        self.radians()                     #각도 지정을 호도법으로 변경
        #청소기로 청소를 하고 있는 느낌을 내기 위해 색 변경(필수는 아님)
        self.width(10)                     #궤적 폭을 10으로 설정
        self.getscreen().bgcolor('gray') #배경을 회색(gray)으로(청소 전의 느낌)
        self.pencolor('white')             #궤적 색을 흰색으로(청소 후의 느낌)
        wn = turtle.Screen()
        self.w = wn.window_width()
        self.h = wn.window_height()
        

    def hit_wall(self):
        xx = self.w / 2.0     #윈도우 폭의 절반이 x 좌표의 최댓값
        yy = self.h / 2.0     #윈도우 높이의 절반이 y 좌표의 최댓값
        #현재 위치와 방향 데이터를 이용해서 Line 클래스의 인스턴스를 생성
        line = Line(math.tan(self.heading()),self.xcor(),self.ycor())
        rand_angle = math.pi * random.random() #안쪽 180도 내에서 임의로 나아갈 방향을 계산 (호도법)

        if self.towards(-xx,yy) > self.heading() >= self.towards(xx,yy): #위쪽 벽에 닿았을 때
            des_x = line.get_x(yy)     # Line형의 메소드 get_x를 사용해서 도달한 점의 x 좌표를 계산
            des_y = yy                 # 도달한 점의 y 좌표는 알고 있으므로 그대로 대입
            turn_angle = self.heading() + rand_angle
        elif self.towards(-xx,-yy) > self.heading() >= self.towards(-xx,yy): #왼쪽 벽에 닿았을 때
            des_x = -xx
            des_y = line.get_y(-xx)
            turn_angle =  self.heading() - 0.5 * math.pi + rand_angle         #오른쪽으로 어느 정도 회전해야 안쪽을 향할지를 계산 (뺄셈은 반시계방향과 같은 의미)
        elif self.towards(xx,-yy) > self.heading() >= self.towards(-xx,-yy): #아래쪽 벽에 닿았을 때
            des_x = line.get_x(-yy)
            des_y = -yy
            turn_angle = self.heading() - rand_angle
        else:                                             #남은 조건은 오른쪽 벽에 닿았을 때의 각도
            des_x = xx
            des_y = line.get_y(xx)
            turn_angle = self.heading() - 0.5 * math.pi - rand_angle

        self.goto(des_x,des_y) #벽에 닿을 때까지 이동
        self.right(turn_angle) #회전해서 안쪽으로 방향을 돌림

    #계속 돌아다니기 위한 메소드
    def run(self):
        while True:
            self.hit_wall()

    def click_on_move(self,x,y):
        self.goto(x,y)