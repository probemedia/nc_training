'''
Created on 2015. 12. 18.

@author: KEO
'''
import sqlite3
#1.Connection객체를 생성
conn = sqlite3.connect('jusik.db') #없으면 생성함
#2.Connection객체를 통한 Cursor 객체를 생성.
cursor = conn.cursor()
#3.Cursor객체의execute 메소드를 사용해서 쿼리 실행.
cursor.execute("SELECT * FROM jusik")
#4.쿼리 결과 처리.
for row in cursor:
    print(row)
#5.DB와의 연결 닫음.
conn.close()