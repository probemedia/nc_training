# coding : utf-8

x = 5
y = 10
x = y
print("x = ", x)
print("y = ", y)
