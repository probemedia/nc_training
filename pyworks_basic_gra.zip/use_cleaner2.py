'''
Created on 2015. 12. 16.

@author: KEO
'''
import cleaner

geobuk = cleaner.Geobuk()
geobuk.getscreen().onclick(geobuk.click_on_move)
geobuk.getscreen().mainloop()
