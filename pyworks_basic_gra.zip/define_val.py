# coding : utf-8

userAge, userName = 30, "철수"

print(userAge, userName)
