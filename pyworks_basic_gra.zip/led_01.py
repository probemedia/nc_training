# coding : utf-8

#라즈베리 파이 확장 커넥터 핀을 범용 입출력(GPIO)핀으로 제어
import RPi.GPIO as GPIO 
import time #시간 딜레이에 사용

GPIO.setmode(GPIO.BOARD) #핀번호 할당방법을 커넥터 핀 번호로 설정
LED = 11 #11번 핀 할당
GPIO.setup(LED, GPIO.OUT, initial=GPIO.LOW) #11번 핀을 출력핀으로 지정하고 초기출력을 어둡게

try:
    while 1: #무한 루프 – 무한히 LED를 제어
        GPIO.output(LED, GPIO.HIGH) #LED밝게
        time.sleep(0.5) #0.5초 딜레이
        GPIO.output(LED, GPIO.LOW) #LED어둡게
        time.sleep(0.5) #0.5초 딜레이
except KeyboardInterrupt:
    pass #아무것도 안함

GPIO.cleanup() #점유된 핀을 해제. 반드시 코딩

