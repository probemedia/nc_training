c = 5

while c > 0 :
    print("c = ", c)
    c -= 1
