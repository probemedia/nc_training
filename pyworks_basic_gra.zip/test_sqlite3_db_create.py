'''
Created on 2015. 12. 18.

@author: KEO
'''
import sqlite3
#1.Connection객체를 생성
conn = sqlite3.connect('jusik.db') #없으면 생성함
#2.Connection객체를 통한 Cursor 객체를 생성.
cursor = conn.cursor()
#3.Cursor객체의execute 메소드를 사용해서 쿼리 실행.
cursor.execute("CREATE TABLE jusik(Name text, ClosingPrice int)")
cursor.execute("INSERT INTO jusik VALUES('LG전자', 51500)")
cursor.execute("INSERT INTO jusik VALUES('삼성전자', 1278000)")
cursor.execute("INSERT INTO jusik VALUES('쿠쿠전자', 234500)")
#4.Connection객체의 commit를 사용해서 변경된 내용 적용.
conn.commit()
#5.DB와의 연결 닫음.
conn.close()