try:
    userInput1 = int(input("input number : "))
    userInput2 = int(input("one more input number : "))
    answer = userInput1 / userInput2
    print("answer = ", answer)
    myFile = open("missing.txt",'r')
except ValueError :
    print("Error : not number")
except ZeroDivisionError :
    print("Error : divide zero")
except Exception as e :
    print("Unknown error : ", e)
