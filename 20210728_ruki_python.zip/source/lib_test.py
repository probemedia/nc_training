# -*- coding: utf-8 -*-
"""
Created on Sun May  3 14:50:38 2020

@author: KEO
"""


def my_val():
    return 10


def my_mul(a, b):
    return a * b
